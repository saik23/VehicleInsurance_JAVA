package VehicleInsurance;

import java.security.cert.PolicyNode;
import java.util.*;
/**
 * Main class that hold together all the information regarding risks, plans, policies, users, claims, and settlements.
 */
public class InsuranceCompany {
    /**
     * Attributes
     */
    private Map<Integer, InsurancePolicy> policyRecord;
    private Map<Integer, Customer> customerRecord;
    private Map<Integer, Receipt> receiptRecord;
    private Map<Integer, Claim> claimRecord;
    private Map<Integer, Settlement> settlementRecord;
    private Map<Integer, Payment> paymentRecord;

    /**
     * Private constructor to allow builder class for instance creation.
     */
    private InsuranceCompany() {
    }

    /**
     * Member functions to keep/update the records
     */
    Customer getCustomerRecord(int customerID) { return this.customerRecord.get(customerID); }

    Receipt getReceiptRecord(int receiptID) {
        return this.receiptRecord.get(receiptID);
    }

    Claim getClaimRecord(int claimID) {
        return this.claimRecord.get(claimID);
    }

    Settlement getSettlementRecord(int settlementID) {
        return this.settlementRecord.get(settlementID);
    }

    InsurancePolicy getPolicyRecord(int policyID) {
        return this.policyRecord.get(policyID);
    }

    Payment getPayment(int paymentID) { return this.paymentRecord.get(paymentID); }

    void updateCustomerRecord(int customerID, Customer customer) {
    }

    void updateReceiptRecord(int receiptID, Receipt receipt) {
    }

    void updateClaimRecord(int claimID, Claim claim) {
    }

    void updateSettlementRecord(int settlementID, Settlement settlement) {
    }

    void updatePolicyRecord(int policyID, InsurancePolicy insurancePolicy) {
    }

    void updatePaymentRecord(int paymentID, Payment payment) {
    }

    // Functionality for the insurance.
    void claimSettlements() {
    }
}

package VehicleInsurance;

/**
 * Settlement class that takes in a claim, checks if settlement is possible, makes the payment to third party,
 * updates the plan details for the vehicle.
 */
public class Settlement {

    /**
     * Attributes: claimID, paymentDue, vehicle
     */
    private int SettlementID;
    private Claim claim;
    private double paymentDue;
    private Vehicle vehicle;
    private Boolean rejected;

    /**
     * Constructor for the class.
     */
    public Settlement() {
    }

    /**
     * Member functions: setter getter methods.
     */

    public int getSettlementID() {
        return SettlementID;
    }

    public double getPaymentDue() {
        return paymentDue;
    }

    public Claim getClaimID() {
        return claim;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public Boolean getRejected() {
        return rejected;
    }

    protected void verifyClaim(){
    }

    // reduces the coverage cap for the plan
    protected void updatePlanCoverageCap() {
    }
    // Reduces vehicle value
    protected void updateVehicleStateAndValue() {
    }

    /**
     * Calls verify, if true makes payment to third party, updates plan details, updates vehicle details.
     */
    public void settle() {
    }

    @Override
    public String toString() {
        return "";
    }
}

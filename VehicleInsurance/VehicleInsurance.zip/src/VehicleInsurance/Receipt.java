package VehicleInsurance;

/**
 * Receipt class to store all the receipt information for payments.
 */
public class Receipt {
    /**
     * Attributes: ID, payee, payer, amount, dateTime.
     */
    private int receiptID;
    private int paymentID;
    private String payee;
    private String payer;
    private String dateTime;

    /**
     * Builder class to be used for the instance creation.
     */
    private Receipt() {
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public void setPayee(String payee) {
        this.payee = payee;
    }

    public void setPayer(String payer) {
        this.payer = payer;
    }

    public void setPaymentID(int paymentID) {
        this.paymentID = paymentID;
    }

    public void setReceiptID(int receiptID) {
        this.receiptID = receiptID;
    }

    @Override
    public String toString() {
        return "";
    }

}

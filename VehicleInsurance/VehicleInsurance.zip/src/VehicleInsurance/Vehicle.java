package VehicleInsurance;

import java.util.*;

/**
 * Vehicle Class for the Insurance company
 * Contains admin info such as Registration Number.
 * Insurance details such as: Policies, State of the vehicle, Damaged parts.
 */
public class Vehicle {
    /**
     * Attributes
     */
    private String registrationNumber;
    private List<InsurancePolicy> policies;
    private double currentValue;
    private List<String> damagedInventory;
    private String currentState;

    /**
     * private Constructor to aid Builder class
     */
    private Vehicle()
    {
    }

    public static VehicleBuilder getBuilder() {
        return new VehicleBuilder();
    }
    public static class VehicleBuilder
    {
        // Same as the base class
        private String registrationNumber;
        private List<InsurancePolicy> policies;
        private double currentValue;
        private List<String> damagedInventory;
        private String currentState;

        private VehicleBuilder() {
        }

        public Vehicle build() {
            return new Vehicle();
        }
    }

    /**
     * Member functions for the class
     */
    /**
     * Function to help the vehicle class view.
     * @return
     */
    @Override
    public String toString() {
        return "";
    }

    public void addPolicy(InsurancePolicy policy) {
    }
    public List<InsurancePolicy> getPolicy() {
        return this.policies;
    }

    public List<String> getDamagedInventory() {
        return this.damagedInventory;
    }

    public void updateInventory(String damagedPart) {
    }

    public void setCurrentValue(double newValue) {
    }

    public void setCurrentState(String state) {
    }
}

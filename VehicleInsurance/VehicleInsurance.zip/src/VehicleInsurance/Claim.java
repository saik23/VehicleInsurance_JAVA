package VehicleInsurance;

import java.util.*;

/**
 * Claim class: User creates a claim against a risk involving third parties(not always).
 * Attributes: claimID, paymentDue, settlementsToBeDone, justifications, policyList.
 */
public class Claim {

    /**
     * Attributes: claimID, paymentDue, settlements, justification, policies
     */
    private int claimID;
    private List<Double> paymentsDue;
    private List<Settlement> settlements;
    private List<String> justification;
    private List<String> damagedInventory;
    private Vehicle vehicle;
    private String dateTime;

    /**
     * private Constructor to aid Builder pattern for instance creation.
     */
    private Claim() {
    }

    /**
     * Member functions: setters and getters
     */
    public int getClaimID() {
        return this.claimID;
    }

    public List<Double> getPaymentsDue() {
        return this.paymentsDue;
    }

    public List<String> getJustification() {
        return this.justification;
    }

    public List<Settlement> getSettlements() {
        return this.settlements;
    }

    public List<String> getDamagedInventory() { return damagedInventory; }

    public String getDateTime() { return dateTime; }

    public void setDateTime() {}

    public void createSettlement(){}

    public Vehicle getVehicle() { return this.vehicle; }

    @Override
    public String toString() {
        return "";
    }
}

package VehicleInsurance;

import java.util.*;

/**
 * Insurance Policy class containing one or more plans for a vehicle.
 * Attributes: Plans, Risks, Claims, Vehicle, PolicyNumber
 */
public class InsurancePolicy {
    /**
     * Attributes
     */
    private List<InsurancePlan> plans;
    private List<Risk> risksCovered;
    private Vehicle vehicle;
    private int policyNumber;

    /**
     * Similar builder class (used in Vehicle class) to be used for this class instantiation as well.
     */
    private InsurancePolicy() {
    }

    /**
     * Member functions.
     */
    public int getPolicyNumber() {
        return this.policyNumber;
    }

    public List<Risk> getRisksCovered() {
        return this.risksCovered;
    }

    public void updateVehicle(double newVehicleValue) {
    }

    public void addPlan(InsurancePlan insurancePlan) {
    }
    public void addRisksCovered(Risk risk) {
    }

    @Override
    public String toString() {
        return "";
    }
}

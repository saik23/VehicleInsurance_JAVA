/**
 * InsurancePlan contains details pertaining to the plan including risks covered, premium, coverage, coverageCap details
 * This class can act as different types of insurances offered by the company based on the risks attribute.
 *
 */
package VehicleInsurance;

import java.util.*;

public class InsurancePlan {

    /**
     * Attributes for the InsurancePlan
     * planNumber: Used for searching a plan
     * risksCovered: Used to identify which risks are covered by the plan
     * premium, Coverage: premium, coverage as percentages for the plan.
     * coverageCap, deathCoverage: maximum coverage for the plan.
     */
    private int planNumber;
    private List<Risk> risksCovered;
    double premium;
    double Coverage;
    double vehicleValue;
    double coverageCap;
    double deathCoverage;

    /**
     * Private Constructor to promote using the builder class for instantiation.
     */
    private InsurancePlan() {
    }

    /**
     * Creates a Builder Class object for the InsurancePlan class
     * @return an InsurancePlanBuilder object
     */
    public static InsurancePlanBuilder getBuilder() {
        return new InsurancePlanBuilder();
    }

    public static class InsurancePlanBuilder {

        /**
         * Contains same attributes as the base class to replicate the construction.
         */
        private int planNumber;
        private List<Risk> risksCovered;
        double premium;
        double Coverage;
        double vehicleValue;
        double coverageCap;
        double deathCoverage;

        /**
         * Making the BuilderClass constructor private to prevent multiple instances.
         */
        private InsurancePlanBuilder() {
        }

        public InsurancePlan build() {
            /**
             * Create the Insurance Plan with default values here and return the object.
             */
            return new InsurancePlan();
        }
    }

    /**
     * Member functions of the class
     */
    @Override
    public String toString() {
        return "";
    }

    public int getPlanNumber() {
        return 0;
    }

    public double getPremium() {
        return 0;
    }

    public double getCoverage() {
        return 0;
    }

    public double getCoverageCap() {
        return 0;
    }

    public double getDeathCoverage() {
        return 0;
    }

    public double updateCoverageCap(double settledAmount) {
        return 0;
    }

    public double updateDeathCoverage() {
        return 0;
    }
}

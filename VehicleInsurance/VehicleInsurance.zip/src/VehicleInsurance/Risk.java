package VehicleInsurance;

/**
 * Risks according to the company.
 */
public enum Risk {
    ObligatoryInsurance, VehicleDamage, VehicleAssistance, PersonalInjury, Death
}
package VehicleInsurance;

import java.util.*;
/**
 * Customer class that contains vehicles, policies for each vehicle
 * Customer can create a claim, and get it settled. Pays premium to activate a plan.
 */
public class Customer {
    /**
     * Attributes: Admin Info: Name, Contact Info, Vehicles, Claims, Payments.
     * Member Functions to: add a policy to a car, payPremium, createClaim
     */
    private String name;
    private String contactInfo;

    private List<Vehicle> vehicles;
    private List<Claim> claims;
    private List<Payment> payments;

    private Customer() {
    }

    /**
     * Member functions: setter and getter methods
     */
    public String getName(){
        return this.name;
    }
    public void setName() {
    }
    public void setContactInfo() {
    }
    public String getContactInfo() {
        return this.contactInfo;
    }

    public void updateVehicles(Vehicle vehicle) {
    }
    public List<Vehicle> getVehicles() {
        return this.vehicles;
    }

    public void makePayment(double paymentAmount) {
    }
    public List<Payment> getPayments() {
        return this.payments;
    }

    public List<Claim> getClaims() {
        return this.claims;
    }

    void addClaim(Claim claim) {
    }

    @Override
    public String toString() {
        return "";
    }
}

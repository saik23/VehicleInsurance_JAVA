package VehicleInsurance;

public class VehicleTest {
    Vehicle vehicle;

    void setup(){
    }

    public void testCurrentState(){
    }
    public void testCurrentValue(){
    }
    public void testDamagedInventory(){
    }
    public void testRegistrationNumber(){
    }
    public void testPolicies(){
    }
}

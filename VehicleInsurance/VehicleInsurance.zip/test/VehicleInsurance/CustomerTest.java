package VehicleInsurance;

public class CustomerTest {
    Customer customer;

    public void setup() {
    }

    // Test individual records
    public void testName(){
    }
    public void testContactInfo(){
    }
    public void testVehicles(){
    }
    public void testClaims(){
    }
    public void testPayments(){
    }
}

package VehicleInsurance;

public class InsurancePlanTest
{
    InsurancePlan ip;

    public void setup(){
    }

    /**
     * Tests for Insurance Plan class
     */
    public void testCoverageCap(){
    }
    public void testDeathCoverage() {
    }
    public void testRisksCovered() {
    }
}

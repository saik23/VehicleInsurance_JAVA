package VehicleInsurance;

public class ClaimTest {
    Claim claim;

    void setup() {
    }

    // Test individual records
    public void testGetVehicle(){
    }
    public void testGetDamagedInventory(){
    }
    public void testGetDateTime(){
    }
    public void testcreateSettlement(){
    }
    public void testPaymentsDue(){
    }
    public void testJustifications(){
    }
}

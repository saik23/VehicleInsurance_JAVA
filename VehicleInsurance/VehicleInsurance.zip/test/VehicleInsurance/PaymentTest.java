package VehicleInsurance;

public class PaymentTest {

    Payment payment;

    void setup(){
    }

    // Unit test for each function
    public void testPremiumAmount(){
    }
    public void testDateTime(){
    }
    public void testGetPaymentID(){
    }
    public void testGetPlanID(){
    }
}

package VehicleInsurance;

public class ReceiptTest {
    Receipt receipt;

    void setup(){
    }

    // Unit test for each function
    public void testGetReceiptID(){
    }
    public void testGetPaymentID(){
    }
    public void testGetPayer(){
    }
    public void testGetPayee(){
    }
    public void testDateTime(){
    }
}

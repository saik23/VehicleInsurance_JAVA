package VehicleInsurance;

public class SettlementTest {
    Settlement settlement;

    void setup(){
    }

    // Unit test for each function
    public void testPaymentDue(){
    }
    public void testVehicle(){
    }
    public void testVerifyClaim(){
    }
    public void testCoverageCapUpdate(){
    }

    // Settlement- Integration test.
    public void testSettle(){
    }
}

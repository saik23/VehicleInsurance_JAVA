package VehicleInsurance;

public class InsurancePolicyTest {

    InsurancePolicy ip;

    public void setup(){
    }

    /**
     * Tests for Insurance Policy class
     */
    public void testRisksCovered(){
    }
    public void testPolicyNumber() {
    }
    public void testPlans() {
    }
    public void testVehicle() {
    }
}
